<?php

    include("DBConn.php");

?>

<!DOCTYPE html>
<html>
    <head>
        <title>Workbook Quest</title>
        <link rel="styleSheet" type="text/css" href="css/styles.css">
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    </head>
    <body>
        
    <div class = "bg-image">
    <div class = "nav" id="myNav">
            <ul>                
                <li><a href="workbookQuest.php" >How it works</a></li>
                <li><a href="bookListLoggedIn.php">Book List</a></li>
                <li><a href="contactUsLoggedIn.php">Contact Us</a></li>
                <li><a href="wishlist.php">Wishlist</a></li>
                <li><a href="account.php">Account</a></li>
                <li><a href="logOut.php" style = "color: white;" class = "active">Log Out</a></li>
                <li><a href="timeToShop.php" style="background:red;"><img alt src="images/cart.png" style="width: 40px; height: 40px;"></a></li>
            </ul>
        </div>
        
       <div class="top" style="height: 100px; background-color: transparent"></div>
       <div class="main">
       <h1 style="font-size: 40px; color: white; ">Log Out</h1>
        
       <div class="textbox" style="border:none;">

        <a href="home.php"><button class="btn" style="height:50px; ">Log out</button></a>

        </div>
       
        </div>
       </div>
    </body>
</html>


