<?php 


if(isset($_GET['action']) && $_GET['action']=="add") 
{
    $id=intval($_GET['id']);
 
    if(isset($_SESSION['cart'][$id])) 
    {
        $_SESSION['cart'][$id]['Stock']++;
    } 
    else 
    { 
        $stmt = $connectMyDB->prepare("SELECT * FROM tblbooks WHERE BookId = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $result = $stmt->get_result()->fetch_assoc();
 
        if(isset($result['BookId']) && $result['BookId']) 
        {
            $_SESSION['cart'][$result['BookId']] = array
            (
                "Stock" => 1,
                "Price" => $result['Price']
            );
        } 
        else 
        {
            $message="This book id is invalid!";
        }
    } 
} 
   
?> 

            <?php 
                if(isset($message)) 
                { 
                    echo "<h2>$message</h2>";
                }
            ?> 
            <table> 
                <tr> 
                    <th>Name</th> 
                    <th>Description</th> 
                    <th>Price</th> 
                    <th>Action</th> 
                </tr> 
                <?php
                   $sql = "SELECT * FROM tblbooks ORDER BY BookTitle";

                   $result = mysqli_query($connectMyDB, $sql);

                   while($row = mysqli_fetch_assoc($result))
                    {
                ?>
                        <tr> 
                            <td><?php echo $row['BookTitle'] ?></td> 
                            <td><?php echo $row['Description'] ?></td> 
                            <td>R <?php echo $row['Price'] ?></td> 
                            <td><a href="timeToShop.php?page=books&action=add&id=<?php echo $row['BookId'] ?>">Add to cart</a></td> 
                        </tr>
                <?php
                    } 
                ?> 
            </table>

        </body>
</html>
