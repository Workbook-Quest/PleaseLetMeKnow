<?php

    include("DBConn.php");

?>

<!DOCTYPE html>
<html>
    <head>
        <title>Workbook Quest</title>
        <link rel="stylesheet" type="text/css" href="css/styles.css">
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    </head>
    <body>
        
    <div class = "bg-image"><!--w3Schools.com-->
    <div class = "nav" id="myNav"><!--The IIE, 2013-->
            <ul>                
                <li><a href="home.php">How it works</a><!--w3Schools.com--></li>
                <li><a href="bookList.php">Book List</a></li>
                <li><a href="contactUs.php">Contact Us</a></li>
                <li><a href="register.php" style="color:white;">Register</a></li>
                <li><a href="login.php" class = "active" style="color:rgb(17, 38, 91);">Login</a></li>
            </ul>
        </div>
        
       <div class="top" style="height: 100px; background-color: transparent"></div>
       <div class="main" style="background-color: transparent">
       <h1 style="font-size: 40px; color: white;">Login</h1>
          
       <div class="textbox" style="border:none;">

        <a href="userLogin.php"><button class="btn" style="height:50px;">Login User</button></a>
        <a href="adminLogin.php"><button class="btn" style="margin-left:30px; height:50px;">Login Admin</button></a>

        </div>

        </div>
       </div>
    </body>
</html>


