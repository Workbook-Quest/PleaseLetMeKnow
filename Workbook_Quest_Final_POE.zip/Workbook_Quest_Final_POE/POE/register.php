<?php

    include("DBConn.php");
    include("errorHandleReg.php");

?>

<!DOCTYPE html>
<html>
    <head>
        <title>Workbook Quest</title>
        <link rel="stylesheet" type="text/css" href="css/styles.css">
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    </head>
    <body>
        
    <div class = "bg-image"><!--w3Schools.com-->
    <div class = "nav" id="myNav"><!--The IIE, 2013-->
            <ul>                
                <li><a href="home.php">How it works</a><!--w3Schools.com--></li>
                <li><a href="bookList.php">Book List</a></li>
                <li><a href="contactUs.php">Contact Us</a></li>
                <li><a href="register.php" class = "active" style="color:rgb(17, 38, 91);">Register</a></li>
                <li><a href="login.php" style="color:white;">Login</a></li>
            </ul>
        </div>
        
       <div class="top" style="height: 100px; background-color: transparent"></div>
       <div class="main" style="background-color: transparent">
       <h1 style="font-size: 40px; color: white; text-align:left">Register</h1>
          
       <form action="" method="POST">
            <div class="reg">
                <label for="name" class="formLabel">Name</label>
            </div>    
                
            <div class="reg">
                <input type="text" placeholder="Input Field" name="Name" class="formtext" value="<?php echo $name; ?>">
                <span class="formErrorLabel"><?php echo $name_error; ?></span>
            </div>

            <div class="reg">
                <label for="surname" class="formLabel">Surname</label>
                </div>    
                
            <div class="reg">
                <input type="text" placeholder="Input Field" name="surname" class="formtext" value="<?php echo $surname; ?>">
                <span class="formErrorLabel"><?php echo $surame_error; ?></span>
            </div>
            <div class="reg">
                <label for="email" class="formLabel">Email</label>
                </div>    
                
            <div class="reg">
                <input type="email" placeholder="Input Field" name="email" class="formtext" value="<?php echo $email; ?>">
                <span class="formErrorLabel"><?php echo $email_error; ?></span>
            </div>
            <div class="reg">
                <label for="stNumber" class="formLabel">Student Number</label>
                </div>    
                
            <div class="reg">
                <input type="text" placeholder="Input Field" name="stNum" class="formtext" value="<?php echo $stNum; ?>">
                <span class="formErrorLabel"><?php echo $stNum_error ; ?></span>
            </div>
            <div class="reg">
                <label for="pswdSet" class="formLabel">Password</label>
                </div>    
                
            <div class="reg">
                <input type="text" placeholder="Input Field" name="pswSet" class="formtext" value="<?php echo $password; ?>">
                <span class="formErrorLabel"><?php echo $password_error; ?></span>
            </div>
            <div class="reg">
                <label for="pswdSetRe" class="formLabel">Password</label><br>
                <label for="re-type" class="formLabel">(Re-type)</label>
            </div>
            
            <div class="reg">
                <input type="text" placeholder="Input Field" name="pswSetRe" class="formtext" value="<?php echo $confirmPassword; ?>">
                <span class="formErrorLabel"><?php echo $confPassword_error; ?></span>
            </div>
            
            <!--button type="submit" name="submit" class="btn btn-primary">Submit</button>&nbsp;&nbsp;&nbsp;&nbsp;-->
            <div class="reg">
                <br><button type="submit" name="submit" class="btn" style="margin-left: 420px; height: 50px; width: 80px;">LOG IN</button>
            </div>
        </form>

        </div>
       </div>
    </body>
</html>

<!--The IIE. 2013.  Heading Levels [WEDE5010 STManual]. The Independent Institute of Education: Unpublished.
  
    --w3Schools.com. How TO - Responsive Top Navigation. [Online] 
    Available at: https://www.w3schools.com/howto/howto_js_topnav_responsive.asp [Accessed 01 April 2021].

    --w3Schools.com. How To - Navbar on Image. [Online]
    Available at: https://www.w3schools.com/howto/howto_css_navbar_image.asp [Accessed 10 May 2021].

    --support.google.com. Make Google Docs, Sheets, Slides & Forms public. [Online]
    Available at: https://support.google.com/docs/search?q=embed+google+forms [Accessed 14 June 2021].
-->
