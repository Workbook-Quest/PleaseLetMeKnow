<?php

include("dbConn.php");

$errorCount =0;
$name = $surname = $email= $num =$altNum =$cardNumber =$exDate = $cvv = $nameCard = $address = $suburb = $CityOrTown = $province = $postalCode = "";
$name_error =$surname_error =$email_error= $num_error = $altNum_error = $cardNumber_error = $exDate_error = $cvv_error = $nameCard_error = $address_error = $suburb_error = $cityOrTown_error = $province_error = $postalCode_error = "";



if(isset($_POST["makePayment"])){
    if(empty($_POST['Name'])){
        $name_error = "Please insert first name.";
        $errorCount++;
    }else{

        $name = $_POST['Name'];
    }
    if(empty($_POST['Surname'])){
        $surname_error = "Please insert surname.";
        $errorCount++;
    }else{
        $surname=$_POST['Surname'];
    }
    if(empty($_POST['Email'])){
        $email_error = "Please enter email.";
        $errorCount++;
    }else{
        $email=$_POST['Email'];
    }
    if(empty($_POST['Num'])){
        $num_error = "Please enter mobile number.";
        $errorCount++;
    }else{
        $num = $_POST['Num'];
    }
    if(empty($_POST['altNum'])){
        $altNum_error = "Please enter the alternative number.";
        $errorCount++;
    }else{
        $altNum =$_POST['altNum'];
    }
    if(empty($_POST['cardNum'])){
        $cardNumber_error="Please enter your card number.";
        $errorCount++;
    }else{
        $cardNumber=$_POST['cardNum'];
    }
    if(empty($_POST['exDate'])){
        $exDate_error="Please enter expiry date of your card.";
        $errorCount++;
    }else{
        $exDate=$_POST['exDate'];
    }
    if(empty($_POST['intCvv'])){
        $cvv_error="Please enter the cvv of your card.";
        $errorCount++;
    }else{
        $cvv=$_POST['intCvv'];
    }
    if(empty($_POST['nameCard'])){
        $nameCard_error = "Please enter the name on the card.";
        $errorCount++;
    }else{
        $nameCard=$_POST['nameCard'];
    }
    if(empty($_POST['address'])){
        $address_error = "Please enter the address.";
        $errorCount++;
    }else{
        $address=$_POST['address'];
    }
    if(empty($_POST['suburb'])){
        $suburb_error = "Please enter your suburb.";
        $errorCount++;
    }else{
        $suburb=$_POST['suburb'];
    }
    if(empty($_POST['cityOrTown'])){
        $cityOrTown_error = "Please enter your city/town.";
        $errorCount++;
    }else{
        $CityOrTown=$_POST['cityOrTown'];
    }
    if(empty($_POST['province'])){
        $province_error = "Please enter your province.";
        $errorCount++;
    }else{
        $province=$_POST['province'];
    }
    if(empty($_POST['postalCode'])){
        $postalCode_error = "Please enter your postal code";
        $errorCount++;
    }else{
        $postalCode=$_POST['postalCode'];
    }

    if($errorCount == 0)
    {
        session_start();
        header('location:login.php');
    }
    unset($_POST["makePayment"]);
}

?>

<!DOCTYPE html>
<html>
    <head>
        <title>Workbook Quest</title>
        <link rel="stylesheet" type="text/css" href="css/styles.css">
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    </head>
    <body>
        
    <div class = "bg-image"><!--w3Schools.com-->
    <div class = "nav" id="myNav"><!--The IIE, 2013-->
            <ul>                
            <li><a href="workbookQuest.php" >How it works</a></li>
                <li><a href="bookListLoggedIn.php">Book List</a></li>
                <li><a href="contactUsLoggedIn.php">Contact Us</a></li>
                <li><a href="wishlist.php">Wishlist</a></li>
                <li><a href="account.php">Account</a></li>
                <li><a href="logOut.php" style = "color: white;">Log Out</a></li>
                <li><a href="timeToShop.php" class = "active"><img alt src="images/cart.png" style="width: 40px; height: 40px;"></a></li style="background:#ed3228;">
            </ul>
        </div>
        
       <div class="top" style="height: 100px; background-color: transparent"></div>
       <div class="main" style="background-color: transparent">
       <h1 style="font-size: 40px; color: white; text-align:left">Payment</h1>

       <form action = "" method = "POST">
        
       <div class="reg">
                <label for="surnameLb" class="formLabel">Bill To</label>
            </div> 

            <div class="reg">
                <label for="nameLb" class="formLabel">First Name</label>
            </div>    
                
            <div class="reg">
                <input type="text" placeholder="Input Field" name="Name" class="formtext" value="<?php echo $name; ?>">
                <span class="formErrorLabel"><?php echo $name_error; ?></span>
            </div>

            <div class="reg">
                <label for="surnameLb" class="formLabel">Last Name</label>
            </div>    
                
            <div class="reg">
                <input type="text" placeholder="Input Field" name="Surname" class="formtext" value="<?php echo $surname; ?>">
                <span class="formErrorLabel"><?php echo $surname_error; ?></span>
            </div>

            <div class="reg">
                <label for="Email" class="formLabel">Contact Email</label>
                </div>    
                
            <div class="reg">
                <input type="email" placeholder="Input Field" name="Email" class="formtext" value="<?php echo $email; ?>">
                <span class="formErrorLabel"><?php echo $email_error; ?></span>
            </div>

            <div class="reg">
                <label for="numLb" class="formLabel">Mobile Number</label>
                </div>    
                
            <div class="reg">
                <input type="text" placeholder="Input Field" name="Num" class="formtext" value="<?php echo $num; ?>">
                <span class="formErrorLabel"><?php echo $num_error; ?></span>
            </div>

            <div class="reg">
                <label for="altNumLb" class="formLabel">Alternative Number</label>
                </div>    
                
            <div class="reg">
                <input type="text" placeholder="Input Field" name="altNum" class="formtext" value="<?php echo $altNum; ?>">
                <span class="formErrorLabel"><?php echo $altNum_error; ?></span>
            </div>

            <div class="reg">
                <label for="detailsLb" class="formLabel">Enter your payment details</label>
                </div>

            <div class="reg">
                <label for="cardNumLb" class="formLabel">Card Number</label>
                </div>    
                
            <div class="reg">
                <input type="text" placeholder="Input Field"  name="cardNum" class="formtext" value="<?php echo $cardNumber; ?>">
                <span class="formErrorLabel"><?php echo $cardNumber_error ; ?></span>
            </div>

            <div class="reg">
                <label for="exDateLb" class="formLabel">Expiry Date </label>
                </div>    
                
            <div class="reg">
                <input type="text" placeholder="Input Field"  name="exDate" class="formtext" value="<?php echo $exDate; ?>">
                <span class="formErrorLabel"><?php echo $exDate_error ; ?></span>
            </div>

            <div class="reg">
                <label for="cvvLb" class="formLabel">Cvv</label>
                </div>    
                
            <div class="reg">
                <input type="text" placeholder="Input Field"  name="intCvv" class="formtext" value="<?php echo $cvv; ?>">
                <span class="formErrorLabel"><?php echo $cvv_error ; ?></span>
            </div>

            <div class="reg">
                <label for="nameCardLb" class="formLabel">Name of Card</label>
                </div>    
                
            <div class="reg">
                <input type="text" placeholder="Input Field"  name="nameCard" class="formtext" value="<?php echo $nameCard; ?>">
                <span class="formErrorLabel"><?php echo $nameCard_error ; ?></span>
            </div>

            <div class="reg">
                <label for="billingAddLb" class="formLabel">Billing Address</label>
                </div>    

            <div class="reg">
                <label for="Addresslb" class="formLabel">Address</label>
            </div> 
                
            <div class="reg">
                <input type="text" placeholder="Input Field" styles="width: 450px; height: 450px;"  name="address" class="formtext" value="<?php echo $address; ?>">
                <span class="formErrorLabel"><?php echo $address_error ; ?></span>
            </div>

            <div class="reg">
                <label for="Suburblb" class="formLabel">Suburb</label>
            </div> 
                
            <div class="reg">
                <input type="text" placeholder="Input Field"  name="suburb" class="formtext" value="<?php echo $suburb; ?>">
                <span class="formErrorLabel"><?php echo $suburb_error ; ?></span>
            </div>
                    
            <div class="reg">
                <label for="cityOrTownLb" class="formLabel">City / Town</label>
            </div> 
                
            <div class="reg">
                <input type="text" placeholder="Input Field"  name="cityOrTown" class="formtext" value="<?php echo $CityOrTown; ?>">
                <span class="formErrorLabel"><?php echo $cityOrTown_error ; ?></span>
            </div>

            <div class="reg">
                <label for="provinceLb" class="formLabel">Province</label>
            </div> 
                
            <div class="reg">
                <input type="text" placeholder="Input Field"  name="province" class="formtext" value="<?php echo $province; ?>">
                <span class="formErrorLabel"><?php echo $province_error ; ?></span>
            </div>

            <div class="reg">
                <label for="postalCodeLb" class="formLabel">Postal Code</label>
            </div> 
                
            <div class="reg">
                <input type="text" placeholder="Input Field"  name="postalCode" class="formtext" value="<?php echo $postalCode; ?>">
                <span class="formErrorLabel"><?php echo $postalCode_error ; ?></span>
            </div>

            <div class="reg">
                <br><button type="submit" name="makePayment" class="btn" style="margin-left: 350px; height: 50px; width: 200px;">PAY</button>
            </div>
    </form>


       

        </div>
       </div>
    </body>
</html>