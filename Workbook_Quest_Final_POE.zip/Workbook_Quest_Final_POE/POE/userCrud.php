<?php

    include("DBConn.php");

?>

<!DOCTYPE html>
<html>
    <head>
        <title>Workbook Quest</title>
        <link rel="stylesheet" type="text/css" href="css/styles.css">
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    </head>
    <body>
        
    <div class = "bg-image">
    <div class = "nav" id="myNav">
            <ul>                
            <li><a href="workbookQuest.php" >How it works</a><!--w3Schools.com--></li>
                <li><a href="bookListLoggedIn.php" class = "active">Book List</a></li>
                <li><a href="contactUsLoggedIn.php">Contact Us</a></li>
                <li><a href="wishlist.php">Wishlist</a></li>
                <li><a href="account.php">Account</a></li>
                <li><a href="logOut.php" style = "color: white;">Log Out</a></li>
                <li><a href="timeToShop.php" style="background:red;"><img alt src="images/cart.png" style="width: 40px; height: 40px;"></a></li>
            </ul>
        </div>
        
       <div class="top" style="height: 100px; background-color: transparent"></div>
       <div class="main" style="background-color: transparent">
       <h1 style="font-size: 40px; color: white; text-align:left">User List</h1>
          
        
        <?php
    session_start();
    if(isset($_SESSION['message'])){
        echo '<div class="alert alert-'.$_SESSION['msg_type'].'">'.$_SESSION['message'].'</div>';
        unset($_SESSION['message']);
    }
?>

    <form action="" method="POST">
    <button type="submit" name="create" class="btn" style="margin-left:40px;"><a href="userAddCrud.php" class="text-light" style="color: white; ">Add a user</a></button>&nbsp;&nbsp;&nbsp;&nbsp;
    <button type="submit" name="create" class="btn" style="margin-left:40px;"><a href="bookListAdmin.php" class="text-light" style="color: white; ">Back</a></button>   
        <table class = "table" style="color: white; border: none; margin-left:40px; margin-top:10px; line-height:1.6;">
            <thead>
                <tr>
                    <th scope="col">UsernameBuyer</th>
                    <th scope="col">BuyerName</th>
                    <th scope="col">BuyerSurname</th>
                    <th scope="col">BuyerEmail</th>
                    <!--th scope="col">BuyerPassword</th-->
                    <th scope="col">StudentNumber</th>
                </tr>
            </thead>
            <?php 
                    $sql = "SELECT * FROM tblbuyer ORDER BY UsernameBuyer";

                    if($connectMyDB === FALSE){
                        echo  "DB Error - " . mysqli_connect_error();
                        exit();
                    }

                    $result = mysqli_query($connectMyDB, $sql);
                    while($row = mysqli_fetch_assoc($result)){
                    
                        $UsernameBuyer = $row['UsernameBuyer'];
                        $BuyerName = $row['BuyerName'];
                        $BuyerSurname = $row['BuyerSurname'];
                        $BuyerEmail = $row['BuyerEmail'];
                        //$BuyerPassword = $row['BuyerPassword'];<td>'.$BuyerPassword.'</td>
                        $StudentNumber = $row['StudentNumber'];
                        
                        
                        echo '<tbody>
                                    <tr>
                                    <td>'.$UsernameBuyer.'</td>
                                        <td>'.$BuyerName.'</td>
                                        <td>'.$BuyerSurname.'</td>
                                        <td>'.$BuyerEmail.'</td>
                                        
                                        <td>'.$StudentNumber.'</td>
                                        <td><button type="submit"name="submitUpdate" class="btn"><a href="updateUser?param='.$UsernameBuyer.'" class="text-light" style="color: white;">Update</a></button>&nbsp;&nbsp;<button type="submit" name="submit" class="btn"><a href="userDelete.php?param='.$UsernameBuyer.'" class="text-light" style="color: white;">Delete</a></button></td>
                                    </tr>
                                </tbody>';
                    }
                    ?>
                    </table>          
          </form>
        </div>
       </div>
    </body>
</html>


