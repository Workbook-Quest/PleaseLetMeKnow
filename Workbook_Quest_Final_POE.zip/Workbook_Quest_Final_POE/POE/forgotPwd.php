<?php

    include("DBConn.php");
    
    $email = "";

    if(isset($_POST) & !empty($_POST))
    {
        $email = mysqli_real_escape_string($connectMyDB, $_POST['email']);

        $sql = "SELECT * FROM tblbuyer WHERE BuyerEmail = $email";

        $resultDB = mysqli_query($connectionMyDB, $sql);

        $count = mysqli_num_rows($resultDB);

        if($count == 1)
        {

            $r = mysqli_fetch_assoc($resultDB);
            $password = $r['BuyerPassword'];
            $to = $r['BuyerEmail'];
            $subject = "Recovered Password";
            
            $message = "Please use this password to login to Workbook Quest " . $password;
            $headers = "From : ST10118146@vcconnect.edu.za";

            if(mail($to, $subject, $message, $headers))
            {
                echo "Your Password has been sent to your email.";
            }
            else
            {
                echo "Error. Your password could not be recovered, please try again. Or contact the admin via contact us webpage.";
            }
        
        }
        else
        {
            echo "Email does not exist in the database.";
        }
    }


?>

<!DOCTYPE html>
<html>
    <head>
        <title>Workbook Quest</title>
        <link rel="stylesheet" type="text/css" href="css/styles.css">
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    </head>
    <body>
        
    <div class = "bg-image">
    <div class = "nav" id="myNav">
            <ul>                
                <li><a href="home.php">How it works</a></li>
                <li><a href="bookList.php">Book List</a></li>
                <li><a href="contactUs.php">Contact Us</a></li>
                <li><a href="register.php" style="color:rgb(17, 38, 91);">Register</a></li>
                <li><a href="login.php" style="color:white;">Login</a></li>
            </ul>
        </div>
        
       <div class="top" style="height: 100px; background-color: transparent"></div>
       <div class="main" style="background-color: transparent">
       <h1 style="font-size: 40px; color: white; text-align:left">Forgot Password</h1>
          
       <form action="" method="POST">
            
            <div class="reg">
                <label for="email" class="formLabel">Email</label>
                </div>    
                
            <div class="reg">
                <input type="email" placeholder="Input Field" name="email" class="formtext" value="<?php echo $email; ?>">
            </div>

              
            <!--button type="submit" name="submit" class="btn btn-primary">Submit</button>&nbsp;&nbsp;&nbsp;&nbsp;-->
            <div class="reg">
                <br><button type="submit" name="submit" class="btn" style="margin-left: 420px; height: 50px; width: 80px;">RECOVER PASSWORD</button>
            </div>
        </form>

        </div>
       </div>
    </body>
</html>


