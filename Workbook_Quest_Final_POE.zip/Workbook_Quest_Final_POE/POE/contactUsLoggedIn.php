<?php

    include("DBConn.php");

    $name =  $email = $num = $comments =$stNumber=$rName= $semail= $surname = "";
    $name_error = $email_error = $num_error = $comments_error =$stNumber_error=$rName_error=$semail_error= $surname_error = "";
    $errorCount=0;
    if (isset($_POST["submitContact"])) 
{
  if (empty($_POST["Name"])) 
  {
    $name_error = "Name is required";
    
  } 
  else 
  {
    $name = $_POST["Name"];
  }

  if (empty($_POST["email"])) 
  {
    $email_error = "Email is required";
    
  } 
  else 
  {
    $email = $_POST["email"];
  }

  if (empty($_POST["num"])) 
  {
    $num_error = "Number is required";
    
  } 
  else 
  {
    $num = $_POST["num"];
  }
    
  if (empty($_POST["comments"])) 
  {
    $comments_error = "Comment is required";
   
  } 
  else 
  {
    $comments = $_POST["comments"];
  }
  if($errorCount>0){
   
  }
  else{

  $To = "ST10118146@vcconnect.edu.za";
  $Subject = "Contact details";
  $Msg = "Name: " .$_POST["Name"]."\nEmail: ".$_POST["email"]."\nNumber: ".$_POST["num"]."\n".$_POST["comments"];
  
$result = mail($To,$Subject,$Msg);
  if($result){
    $resultMsg = "Your message was successfully sent.";
   echo $resultMsg;    //the mail part doesn't work because of the php.ini i am not sure
  }
   else{
     $resultMsg ="There was a problem sending your message.";
   echo $resultMsg;
   }
  }

}

if (isset($_POST["Request"])) 
{
  if (empty($_POST["stNumber"])) 
  {
    $stNumber_error = "Student number is required";
    
  } 
  else 
  {
    $stNumber = $_POST["stNumber"];
  }

  if (empty($_POST["semail"])) 
  {
    $semail_error = "Email is required";
    
  } 
  else 
  {
    $semail = $_POST["semail"];
  }

  if (empty($_POST["rName"])) 
  {
    $rName_error = "Name is required";
    
  } 
  else 
  {
    $rName = $_POST["rName"];
  }
    
  if (empty($_POST["surname"])) 
  {
    $surname_error = "Surname is required";
   
  } 
  else 
  {
    $surname = $_POST["surname"];
  }
  if($errorCount>0){
   
  }
  else{

  $To = "ST10118146@vcconnect.edu.za";
  $Subject = "Request to be seller";
  $Msg = "Student Number: " .$_POST["stNumber"]."\nEmail: ".$_POST["email"]."\nName: ".$_POST["rName"].$_POST["surname"];
  
$result = mail($To,$Subject,$Msg);
  if($result){
    $resultMsg = "Your request was successfully sent.";
   echo $resultMsg;    //the mail part doesn't work because of the php.ini i am not sure
  }
   else{
     $resultMsg ="There was a problem sending your request.";
   echo $resultMsg;
   }
  }
} 
?>

<!DOCTYPE html>
<html>
    <head>
        <title>Workbook Quest</title>
        <link rel="styleSheet" type="text/css" href="css/styles.css">
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    </head>
    <body>
        
    <div class = "bg-image">
    <div class = "nav" id="myNav">
            <ul>                
            <li><a href="workbookQuest.php" >How it works</a></li>
                <li><a href="bookListLoggedIn.php" class = "active">Book List</a></li>
                <li><a href="contactUsLoggedIn.php">Contact Us</a></li>
                <li><a href="wishlist.php">Wishlist</a></li>
                <li><a href="account.php">Account</a></li>
                <li><a href="logOut.php" style = "color: white;">Log Out</a></li>
                <li><a href="timeToShop.php" style="background:red;"><img alt src="images/cart.png" style="width: 40px; height: 40px;"></a></li>
            </ul>
        </div>
        
       <div class="top" style="height: 100px; background-color: transparent"></div>
       <div class="main">
       <h1 style="font-size: 40px; color: white; text-align:left">Contact Us</h1>
        
       <h3 style="color:white; text-align:left; ">Contact Form<br></h3>
       <div class="paragraph">
        

        <p>We love getting feedback from our users. If you have any suggestions that will help us to improve your experience on our site, 
        then please send us an email on info@varsitycollegbooks.edu.za. If we have not included your book/ nook details or book prices 
        are incorrect, please include as much details as possible below so we can update our site.</p><br><br>

        <form action="" method="POST">
            <div class="reg">
                <label for="name" class="formLabel">Your Name</label>
            </div>    
                
            <div class="reg">
                <input type="text" placeholder="Input Field" name="Name" class="formtext" value="<?php echo $name; ?>">
                <span class="formErrorLabel"><?php echo $name_error; ?></span>
            </div>

            <div class="reg">
                <label for="email" class="formLabel">Contact Email</label>
                </div>    
                
            <div class="reg">
                <input type="email" placeholder="Input Field" name="email" class="formtext" value="<?php echo $email; ?>">
                <span class="formErrorLabel"><?php echo $email_error; ?></span>
            </div>
            <div class="reg">
                <label for="num" class="formLabel">Mobile Number</label>
                </div>    
                
            <div class="reg">
                <input type="num" placeholder="Input Field" name="num" class="formtext" value="<?php echo $num; ?>">
                <span class="formErrorLabel"><?php echo $num_error; ?></span>
            </div>
            <div class="reg">
                <label for="comments" class="formLabel">Your Comments</label>
                </div>    
                
            <div class="reg">
                <input type="text" placeholder="Input Field" style="width: 250px; height: 200px;" name="comments" class="formtext" value="<?php echo $comments; ?>">
                <span class="formErrorLabel"><?php echo $comments_error ; ?></span>
            </div>
                        
            <div class="reg">
                <br><button type="submitContact" name="submitContact" class="btn" style="margin-left: 350px; height: 50px; width: 200px;">SEND MESSAGE</button>
            </div>
        </form><br><br>
        </div>

        <hr>

        <h3 style="color:white; text-align:left; ">To be a Seller<br></h3>
        <div class="paragraph">
        <p>If you want to be a seller you can request here by writing your student number, email, name and surname. We will then notify 
            you if you can be a seller or not.</p><br><br>

            
        <form action="" method="POST">   
        <div class="reg">
                <label for="stNumber" class="formLabel">Student Number</label>
                </div>   
        <div class="reg">
                <input type="text" placeholder="Input Field" name="stNumber" class="formtext" value="<?php echo $stNumber; ?>">
                <span class="formErrorLabel"><?php echo $stNumber_error; ?></span>
            </div>
            <div class="reg">
                <label for="email" class="formLabel">Contact Email</label>
                </div>    
                
            <div class="reg">
                <input type="email" placeholder="Input Field" name="semail" class="formtext" value="<?php echo $semail; ?>">
                <span class="formErrorLabel"><?php echo $semail_error; ?></span>
            </div>
            <div class="reg">
                <label for="rName" class="formLabel">Your Name</label>
            </div>    
                
            <div class="reg">
                <input type="text" placeholder="Input Field" name="rName" class="formtext" value="<?php echo $rName; ?>">
                <span class="formErrorLabel"><?php echo $rName_error; ?></span>
            </div>
            <div class="reg">
                <label for="surname" class="formLabel">Your Surname</label>
            </div>    
                
            <div class="reg">
                <input type="text" placeholder="Input Field" name="surname" class="formtext" value="<?php echo $surname; ?>">
                <span class="formErrorLabel"><?php echo $surname_error; ?></span>
            </div>
                        
            <div class="reg">
                <br><button type="submitRequest" name="Request" class="btn" style="margin-left: 420px; height: 50px; width: 80px;">REQUEST</button>
            </div>
        </form>
        </div>

        </div>
       </div>
    </body>
</html>


