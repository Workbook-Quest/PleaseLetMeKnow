<?php
session_start();
 
include("demoDB.php");

// Check if the user is already logged in, if yes then redirect him to welcome page
if(isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true){
    header("location: workbookQuest.php");
    exit;
}
 

 $countError = 0;
 $username_error= $pwdInput_error ="";
 $username = $pwdInput = $login_err="";

 if(isset($_POST["logIn"]))
 {
 
  // Check if username is empty
  if(empty($_POST['username']))
  {
      $username_error = "Please enter username.";
      $countError++;
  } 
  else
  {
      $username = $_POST['username'];
  }
  
  // Check if password is empty
  if(empty($_POST['pwdInput']))
  {
      $pwdInput_error = "Please enter your password.";
      $countError++;
  } 
  else
  {
      $pwdInput = $_POST['pwdInput'];
  }
  //https://www.tutorialrepublic.com/php-tutorial/php-mysql-login-system.php;
 
 /*if(empty($username_error) && empty($pwd_error)){
    // Prepare a select statement
    $sql = "SELECT UsernameBuyer, BuyerPassword FROM tblbuyer WHERE username = ?";
    
    if($stmt = mysqli_prepare($dbconnect, $sql)){
      
      mysqli_stmt_bind_param($stmt, "s", $param_username);
      
      $param_username = $username;
            
            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                // Store result
                mysqli_stmt_store_result($stmt);
                
                
                if(mysqli_stmt_num_rows($stmt) == 1){                    
                 
                    mysqli_stmt_bind_result($stmt, $username, $hashed_password);

                    if(mysqli_stmt_fetch($stmt)){

                        if(password_verify($pwdInput, $hashed_password)){
                            
                            session_start();

                            $_SESSION["loggedin"] = true;
                            
                            $_SESSION["username"] = $username; 
                            header("location: workbookQuest.php");
                          } else{
                            // Password is not valid, display a generic error message
                            $login_err = "Invalid username or password.";
                        }
                    }
                } else{
                    // Username doesn't exist, display a generic error message
                    $login_err = "Invalid username or password.";
                }
            } else{
                echo "Oops! Something went wrong. Please try again later.";
            }

            // Close statement
            mysqli_stmt_close($stmt);
        }
    
      }
    // Close connection
    mysqli_close($dbconnect);*/


    if($countError ==0)
    {

      $passCheck = password_hash($pwdInput);

      $sql = "SELECT UsernameBuyer,BuyerEmail,BuyerPassword FROM tblbuyer WHERE BuyerEmail = '$username' && BuyerPassword ='$pwdInput' ";
    
    $dbResult = mysqli_query($dbconnect,$sql);

    if($dbResult === FALSE)
    {
      echo "Error: ".mysqli_connect_error();
    }
    else
    {
      session_start();
      $_SESSION['message'] ="User has been logged in succesfully.";
      $_SESSION['msg_type']="success";
      header('location:workbookQuest.php');

      mysqli_close($dbconnect);
      $dbconnect=FALSE;
    
    }
    unset($_POST["logIn"]);
      }
    }
?>

<!DOCTYPE html>
<html>
    <head>
        <title>Workbook Quest</title>
        <link rel="stylesheet" type="text/css" href="styelsSheet.css">
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    </head>
    <body>
        
    <div class = "bg-image"><!--w3Schools.com-->
    <div class = "nav" id="myNav"><!--The IIE, 2013-->
            <ul>                
                <li><a href="home.php">How it works</a><!--w3Schools.com--></li>
                <li><a href="bookList.php">Book List</a></li>
                <li><a href="contactUs.php">Contact Us</a></li>
                <li><a href="register.php" style="color:white;">Register</a></li>
                <li><a href="login.php" class = "active" style="color:rgb(17, 38, 91);">Login</a></li>
            </ul>
        </div>
        
       <div class="top" style="height: 100px; background-color: transparent"></div>
       <div class="main" style="background-color: transparent">
       <h1 style="font-size: 40px; color: white; text-align:left">Login</h1>
       <?php 
        if(!empty($login_err)){
            echo '<div class="alert alert-danger">' . $login_err . '</div>';
        }        
        ?>
       <form action="" method="POST">
            <div class="reg">
                <label for="name" class="formLabel">Username</label><br>
                <label for="noteName" class="formLabel">(Email / Student Number)</label>
            </div>    
                
            <div class="reg">
                <input type="text" placeholder="Input Field" name="username" class="formtext" value="<?php echo $username;?>">
                <span class="formErrorLabel"><?php echo $username_error; ?></span>
            </div>

            <div class="reg">
                <label for="pwd" class="formLabel">Password</label>
                </div>    
                
            <div class="reg">
                <input type="text" class="formtext" placeholder="Input Field" name="pwdInput"/>
            </div>
            
            <!--button type="submit" name="submit" class="btn btn-primary">Submit</button>&nbsp;&nbsp;&nbsp;&nbsp;-->
            <div class="reg" style = "line-height: 6.6;">
                <button type="submit" name="forgPass" class="btn" style="margin-left: 30px; height: 50px; width: 200px;">FORGOT PASSWORD</button>
                <button type="submit" name="logIn" class="btn" style="margin-left: 30px; height: 50px; width: 120px;">LOG IN</button>
                <button type="submit" name="reg" class="btn" style="margin-left: 30px; height: 50px; width: 120px;">REGISTER</button>
            </div>
        </form>

        </div>
       </div>
    </body>
</html>


<!DOCTYPE html>
<html>
    <head>
        <title>Workbook Quest</title>
        <link rel="stylesheet" type="text/css" href="styleSheet.css">
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    </head>
    <body>
        
    <div class = "bg-image"><!--w3Schools.com-->
    <div class = "nav" id="myNav"><!--The IIE, 2013-->
            <ul>                
                <li><a href="home.php">How it works</a><!--w3Schools.com--></li>
                <li><a href="bookList.php">Book List</a></li>
                <li><a href="contactUs.php">Contact Us</a></li>
                <li><a href="register.php" style="color:white;">Register</a></li>
                <li><a href="login.php" class = "active" style="color:rgb(17, 38, 91);">Login</a></li>
            </ul>
        </div>
        
       <div class="top" style="height: 100px; background-color: transparent"></div>
       <div class="main" style="background-color: transparent">
       <h1 style="font-size: 40px; color: white; text-align:left">Login</h1>
       <?php 
        if(!empty($login_err)){
            echo '<div class="alert alert-danger">' . $login_err . '</div>';
        }        
        ?>
       <form action="" method="POST">
            <div class="reg">
                <label for="name" class="formLabel">Username</label><br>
                <label for="noteName" class="formLabel">(Email / Student Number)</label>
            </div>    
                
            <div class="reg">
                <input type="text" placeholder="Input Field" name="username" class="formtext" value="<?php echo $username;?>">
                <span class="formErrorLabel"><?php echo $username_error; ?></span>
            </div>

            <div class="reg">
                <label for="pwd" class="formLabel">Password</label>
                </div>    
                
            <div class="reg">
                <input type="text" placeholder="Input Field" name="pwdInput" class="formtext" value="<?php echo $pwdInput;?>">
                <span class="formErrorLabel"><?php echo $pwdInput_error; ?></span>
            </div>
            
            <!--button type="submit" name="submit" class="btn btn-primary">Submit</button>&nbsp;&nbsp;&nbsp;&nbsp;-->
            <div class="reg" style = "line-height: 6.6;">
                <button type="submit" name="forgPass" class="btn" style="margin-left: 30px; height: 50px; width: 200px;">FORGOT PASSWORD</button>
                <button type="submit" name="logIn" class="btn" style="margin-left: 30px; height: 50px; width: 120px;">LOG IN</button>
                <button type="submit" name="reg" class="btn" style="margin-left: 30px; height: 50px; width: 120px;">REGISTER</button>
            </div>
        </form>

        </div>
       </div>
    </body>
</html>



