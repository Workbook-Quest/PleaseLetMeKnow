----------------------------------README---------------------------------

Workbook Quest is a web developed file that can be compiled by navigation:
• Activate Wamp Server
• Workbook Quest File
	o POE
	     > home.php

Run program:
• Follow the navigation instructions above.
• Click on an internet browser, then enter the url to navigate the to the home.php. path.

How the program works:
These web developed files are programmed in php and open the path in a internet browser. It is designed and developed so that college students from varsity college can access a website to buy and sell used colleg books. 

In this website there are various files that contain the required code or other files, such as:

• images
  o images of all the images used throughout the website.

• POE_txt_files
  o extraWEDEcodePOE_part3 -- contains files used for backup.
  o adminData.txt -- data used in the admin table.
  o booksData.txt -- data used in the books table.
  o orderData.txt -- data used in the order table.
  o userData.txt -- data used in the buyer table. 
  o ReadMe.txt -- this page that is currently being read.

• css
  o styles.css -- this is the styleSheet for all the styling or deisgn done for the entire website.

> account.php -- the user or admins account details will display in here. It contians both html and php language.
> AddBook.php -- the admin will be able to add new books to the database. It contians both html and php language.
> adminLogin.php -- the admin will be able to login to the website here. It only contians php language.
> bookList.php -- this is just a closed book page that does not show the list of books. It contians both html and php language.
> bookListAdmin.php -- the admin will be shown what the list of books are, various buttons to be reditected to the needed webpages. It contians both html and php language.
> bookListLoggedIn.php -- the user will be able to see the list of books as well as add the chosen books to the "Wishlist and Shopping cart". It contians both html and php language.
> books.php -- users see the list of all the books in the database. It contians both html and php language.
> cart.php -- this is the view cart page. It contians both html and php language.
> contactUs -- users who are not registered can contact the admin through here if they need information but do not wish or need to register. It contians both html and php language.
> contactUsLoggedIn.php -- users can contact the admin about any inqueries they have here as well as send a request to be a seller. It contians both html and php language.
> createTable.php -- here the userData.txt will be loaded in the PHPMyAdmin. 
> DBConn.php -- this is the connection file. Here the php files can be connected to the database. It only contians php language.
> delete.php -- a book can be deletef from the database here. It only contians php language.
> errorHandleLogin.php -- this file checks the user login page and all the user input values are checked for any errors. It only contians php language.
> errorHanleLoginAdmin.php -- this file checks the admins login page and all the admin input values are checked for any errors. It only contians php language.
> errorHandleReg.php -- this file checks the user register page and all the user input values are checked for any errors. It only contians php language.
> forgotPwd.php -- here is where users can recover their password incase they forgot it. It contians both html and php language.
> forgotPwdAdmin.php -- here is where admin can recover their password incase they forgot it. It contians both html and php language.
> home.php -- this is the welcome page that all users and admin see first when go to the webpage. It only contians html language.
> login.php -- this webpage only contains the buttons so that they can be redirected to the admin or user login pages. It only contians html language.
> logOut.php -- Here the users and admin can log out. It only contians html language.
> payment.php -- once the user checks out they they will be redirected to this webpage and then they'll be able to pay for the books. It contians both html and php language.
> register.php -- this is where the webpage contians the html so that the users can register can become a buyer. It only contians html language.
> sellBook.php -- here the user can sell their books. It contians both html and php language.
> timeToShop -- users can choose the books to add to their cart. It contians both html and php language. 
> updateBooks.php -- here the books information can be updated. It contians both html and php language.
> updateUser.php -- here the users information can be updated. It contians both html and php language.
> userAddCrud.php -- here the users can be added in case there is trouble registering. It contians both html and php language.
> userCrud.php -- the admin will be shown what the list of users are, various buttons to be reditected to the needed webpages. It contians both html and php language.
> userDelete.php -- the users can be deleted from the database but only the admin has access. It only contians php language.
> userLogin.php -- this is the users login webpage, it just contains the html.
> wishlist.php -- here the users can store in the list of books they wish to have but they do not have money yet, so they cannot add it to the cart. It contians both html and php language.
> workbookQuest.php -- this is the home page for when the admin and users are logged in. It only contians html language.


References:

Adams, D. (2019). Shopping Cart System with PHP and MySQL. [online] CodeShack. Available at: https://codeshack.io/shopping-cart-system-php-mysql/ [Accessed 02 July 2022].
Code Envato Tuts+. (n.d.). Build a Shopping Cart With PHP and MySQL. [online] Available at: https://code.tutsplus.com/tutorials/build-a-shopping-cart-with-php-and-mysql--net-5144 [Accessed 02 July 2022].
Parvez (2021). How To Reset Password by Email Using PHP7 and MySQLi. [online] Phpflow.com. Available at: https://www.phpflow.com/php/how-to-reset-password-by-email-using-php7-and-mysqli/ [Accessed 3 Jul. 2022].
www.studentstutorial.com. (n.d.). PHP CRUD Example. [online] Available at: https://www.studentstutorial.com/php/php-crud.php [Accessed 02 July 2022].


‌


