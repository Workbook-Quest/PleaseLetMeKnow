<?php 
if (isset($_POST['submit'])) 
{
    foreach($_POST['Stock'] as $key => $val) 
    {
        if($val==0) 
        {
            unset($_SESSION['cart'][$key]);
        }
        else
        {
            $_SESSION['cart'][$key]['Stock']=$val;
        }
    }
}
?> 
 

<div class="textbox">
<h1>View cart</h1> 
<a href="timeToShop.php?page=books"><button class="btn" style="height:50px;">Back</button></a>
<form method="post" action="timeToShop.php?page=cart">
    <table>
        <tr>
            <th>Name</th>
            <th>Quantity</th>
            <th>Price</th>
            <th>Items Price</th>
        </tr>

        <?php 
            $arrProductIds=array();

            foreach ($_SESSION['cart'] as $id => $value) 
            {
                $arrProductIds[] = $id;
            }
            $strIds=implode(",", $arrProductIds);
 
            $stmt = $connectMyDB->prepare("SELECT * FROM tblbooks WHERE BookId IN (?)");
            $stmt->bind_param("s", $strIds);
            $stmt->execute();
            $result = $stmt->get_result();
 
            $totalprice=0; 
            while ($row = $result->fetch_assoc()) 
            {
                $subtotal=$_SESSION['cart'][$row['BookId']]['Stock']*$row['Price']; 
                $totalprice+=$subtotal; 
            ?>
                <tr> 
                    <td><?php echo $row['BookTitle'] ?></td> 
                    <td><input type="text" name="Stock[<?php echo $row['BookId'] ?>]" size="5" value="<?php echo $_SESSION['cart'][$row['BookId']]['Stock'] ?>" /></td> 
                    <td>R<?php echo $row['Price'] ?></td> 
                    <td>R<?php echo $_SESSION['cart'][$row['BookId']]['Stock']*$row['Price'] ?></td> 
                </tr> 
            <?php 
            }
        ?> 
        <tr style="margin-left: 320px;"> 
            <td colspan="4" >Total Price: <?php echo $totalprice ?></td> 
        </tr> 
    </table> 
    <br /> 
    <button type="submit" name="submit" class="btn" style="height:50px;">Update Cart</button> 
    
</form> 
<br /> 
<p>To remove an item set its quantity to 0. </p>

</div>




