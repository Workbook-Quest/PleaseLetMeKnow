<?php
//Session initialized
session_start();

//include connection source code.
 include("DBConn.php");

 //Check to see if the user has already logged in. If the user is logged in then redirect them to Workbook Quest home logged in.
 if(isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true)
 {
    header("location: accountAdmin.php");
    exit;
}

//error count equals to zero.
 $countError = 0;
 //initialize with emty value the newly declared variables.
 $adminUsername_error = $adminPwd_error = "";
 $adminUsername = $adminPwd = "";

 //If register.php submit button has been clicked then do the following.
 if(isset($_POST["submitAdminLog"]))
 {
     //If input value of type=name is empty then the following error message will display.
    if(empty($_POST['adminUsername']))
    {
        $adminUsername_error = "Please input the username.";
        $countError++;//error count starts to count.
    }
    else//if it is not empty then $name = type=name. 
    {
        $adminUsername = $_POST['adminUsername'];
    }

    if(empty($_POST['adminPwd']))
    {
        $adminPwd_error = "Please input the password.";
        $countError++;
    }
    else
    {
        $adminPwd = $_POST['adminPwd'];
    }

    if($countError ==0)
    {

      $passCheck = password_hash($adminPwd, PASSWORD_DEFAULT);//hash the password
      //password_hash($pwdInput, PASSWORD_DEFAULT);

      $sql = "SELECT AdminUsername,	AdminName, AdminSurname	,AdminEmail	, AdminPassword FROM tbladmin WHERE AdminUsername = '$adminUsername' && AdminPassword ='$adminPwd'";//admin from admin table.
    
    $dbResult = mysqli_query($connectMyDB,$sql);

    if($dbResult === FALSE)//if the connection is false then print out error.
    {
      echo "Error accessing the statement: ".mysqli_connect_error();
    }
    else
    {
      session_start();
      $_SESSION['message'] ="User has been logged in succesfully.";
      $_SESSION['msg_type']="success";
      header('location: accountAdmin.php');

      mysqli_close($connectMyDB);
      $connectMyDB=FALSE;
    
    }
    unset($_POST["submitAdminLog"]);
      }
    
    }
  

?>